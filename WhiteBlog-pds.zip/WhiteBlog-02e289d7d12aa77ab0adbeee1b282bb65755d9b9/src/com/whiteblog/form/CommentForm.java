package com.whiteblog.form;

public class CommentForm {
	String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
